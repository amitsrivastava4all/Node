const bcrypt = require('bcrypt');

const passwordHashing = {
    SALT : 10,
    hashPassword(plainPassword){
        
        const hashedPwd = bcrypt.hashSync(plainPassword, parseInt(this.SALT));
        return hashedPwd;
    },
    comparePwd(plainPassword, dbPassword){
        return bcrypt.compareSync(plainPassword, dbPassword);
    }
}
module.exports = passwordHashing;