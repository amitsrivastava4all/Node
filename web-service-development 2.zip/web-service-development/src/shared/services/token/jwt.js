const jwt = require('jsonwebtoken');

const SECRET = 'UCANTSEEME';
const generateToken = (email)=>{
    const token = jwt.sign({email:email},SECRET,{
        
        expiresIn:'1d',

    });
    return token;
}

const compareToken = (token)=>{

}
module.exports = {generateToken, compareToken};