const mongoose = require('mongoose');
console.log('Mongoose Maintain Connection Array ', mongoose.connections);
/*
 There r 2 ways to create a connection in Mongoose.
 1. mongoose.createConnection(url); - it gives the new connection
 2. mongoose.connect(url);
*/
const promise = mongoose.connect(process.env.DB_URL,{maxPoolSize:5});
promise.then(value=>{
    console.log('Connection Created...');
}).catch(err=>{
    console.log('Connection Error ',err);
})
module.exports = mongoose;
