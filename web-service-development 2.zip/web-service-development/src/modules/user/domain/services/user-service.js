// CRUD 
const UserModel = require('../models/user-schema');
const {hashPassword, comparePwd} = require('../../../../shared/services/encryption/password-hashing');
const userService = {
    async addNewUser(userObject){
        userObject.password = hashPassword(userObject.password);
        return await UserModel.create(userObject); // Implict throw Exception
    },
    async loginUser(userObject){
        try{
            const doc = await UserModel
            .findOne({'email':userObject.email},
            {'email':1, 'password':1, 'name':1,'phone':1,'_id':0}).exec();
            if(doc && doc.email){
                if(comparePwd(userObject.password, doc.password)){
                    return {'name':doc.name, 'email':doc.email};
                }
                return null;
            }
            return null;
        }
        catch(err){
            throw err;
           // throw new Error('hgdkfjhgkjf')
        }
    }
}
module.exports = userService;