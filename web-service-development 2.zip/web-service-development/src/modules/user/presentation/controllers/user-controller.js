// const userController = {
//     register(request, response){

const { generateToken } = require("../../../../shared/services/token/jwt");
const userService = require("../../domain/services/user-service");
const {SUCCESS, SERVER_ERROR, RESOURCE_NOT_FOUND}= require('../../../../shared/utils/constants/app-constants').STATUS_CODES;

//     },
//     login(request, response){

//     },
//     profile(request , response){

//     }
// }
const appLogger = require('../../../../shared/services/logger/app-logger')(__filename); 
const register=async (request, response)=>{
 // URL Encoded Form (Form Submit) - email=amit@yahoo.com&password=12222
 // JSON {key:value} (react, angular, Flutter)
 const body = request.body;
 try{
 const result = await userService.addNewUser(body);
 response.status(SUCCESS).json({result: result});
 }
 catch(err){
   console.log(err);
    response.status(SERVER_ERROR).json({message: 'Error During Register....'});
    appLogger.error('Problem in User Register'+JSON.stringify(err));
 }

}
const login = async (request, response)=>{
  const body = request.body;
  try{
  const result = await userService.loginUser(body);
  if(result && result.name){
    const token = generateToken(result.email);
    response.status(SUCCESS).json({message:'Welcome '+result.name, token: token});
  }
  else{
    response.status(RESOURCE_NOT_FOUND).json({message:'Invalid EmailId or Password'});
  }
  }
  catch(err){
    console.log(err);
    response.status(SERVER_ERROR).json({message: 'Error During Login....'});
  }
}
const profile = (request, response)=>{

}
module.exports = {register, login, profile};
//module.exports = userController;
//module.exports = {userController.register, userController.login}