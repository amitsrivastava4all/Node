const express = require('express');
const router = express.Router();
const {REGISTER, LOGIN, PROFILE} = require('../../../../shared/utils/constants/app-constants').ROUTES.USER_ROUTES;
const {register, login , profile } = require('../controllers/user-controller');
router.get(PROFILE, profile);
router.post(REGISTER, register);
router.post(LOGIN, login);
module.exports = router;