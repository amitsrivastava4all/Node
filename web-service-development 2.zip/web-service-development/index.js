const express = require('express');
const app = express();
const chalk = require('chalk');
const morgan= require('morgan');
const cors = require('cors');
const {API_VERSION} = require('./src/shared/utils/constants/app-constants').ROUTES;
const appLogger = require('./src/shared/services/logger/app-logger')(__filename);
require('dotenv').config();
const serverLogStream = require('./src/shared/services/logger/server-logger');
// Load Env
// app.use(middleware); 
// middleware function
app.use(cors());
app.use(morgan('combined',{stream:serverLogStream}));
app.use(express.urlencoded());
app.use(express.json());
app.use(API_VERSION, require('./src/modules/user/presentation/routes/user-route'));
app.use(require('./src/shared/middlewares/404'));
// app.get('/' , (req, res)=>{
//     res.setHeader('Access-Control-Allow-Origin', '10.10.20.1')
// })
const server = app.listen(process.env.PORT , (err)=>{
    if(err){
        console.log(chalk.red.bold('Server Crash '), err);
        appLogger.error('Server Crash')
    }
    else{
        console.log(chalk.greenBright.
            bold('Server Up and Running '+server.address().port));
            appLogger.debug('Server Up and Running');
    }
})