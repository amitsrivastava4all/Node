const { SchemaTypes } = require('mongoose');
const {USERS} = require('../../../../shared/utils/constants/app-constants').SCHEMA;
const mongoose = require('../../../../shared/services/db/connection');
const Schema = mongoose.Schema;
const userSchema = new Schema({
    'email':{type:SchemaTypes.String, required:true, 
        lowercase:true, unique:true},
     'password':{type:SchemaTypes.String , 
        minLength:3, maxLength:25, trim:true, required:true},
        'name':{type:SchemaTypes.String, required:true},
        'phone':{type:Schema.String,  validate:{
            validator:function(phoneValue){
                let max = 10;
                if(phoneValue.length!=max){
                    return false;
                }
                return true;
            },
            message:function(prop){
                let fieldName = prop.path;
                return 'Invalid Phone Number '+fieldName+'  '+prop.value;
            }
        }}

});
const UserModel = mongoose.model(USERS,userSchema);
module.exports = UserModel;