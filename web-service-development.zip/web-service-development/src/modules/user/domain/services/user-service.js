// CRUD 
const UserModel = require('../models/user-schema');
const userService = {
    async addNewUser(userObject){
        return await UserModel.create(userObject);
    }
}
module.exports = userService;