#!/usr/bin/env node
import { createSpinner } from 'nanospinner'
import Gauge from 'gauge';
import figlet  from 'figlet';
import inquirer from 'inquirer';
import { program } from 'commander';
function loadingSpinner(){
    const spinner = createSpinner('Loading...').start({
        text:'Loading Data', color:'red'
    });
    setTimeout(()=>{
        spinner.success();
    },3000);
}




function showProgress(){
    var gauge = new Gauge()

gauge.show("working…", 0)
setTimeout(() => { gauge.pulse(); gauge.show("working…", 0.25) }, 500)
setTimeout(() => { gauge.pulse(); gauge.show("working…", 0.50) }, 1000)
setTimeout(() => { gauge.pulse(); gauge.show("working…", 0.75) }, 1500)
setTimeout(() => { gauge.pulse(); gauge.show("working…", 0.99) }, 2000)
setTimeout(() => gauge.hide(), 2300)
}



function intro(bigText){
    figlet(bigText, function (err, data) {
        if (err) {
          console.log("Something went wrong...");
          console.dir(err);
          return;
        }
        console.log(data);
      });
}



function askInput(){
    inquirer.prompt([{
        "name":"newsans","message":"Press P For Pol S for Spo "
        
    }]).then(answers=>{
        console.log('Answer Rec ',answers);
    }).catch(err=>{
        console.log('Error is ', err);
    })
}

function myCommand(){
    program.name('latest-news-cli')
    .description('This is a news cli')
    .version('1.0','-v, --version')
    .option('-t --top <language>')
    .option('-o --old [year]').parse(process.argv);
    
    const options = program.opts();
    console.log('Options ', options);
}

myCommand();
//loadingSpinner();
//showProgress();
//intro("News App");
//askInput();