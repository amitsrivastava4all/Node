module.exports = function(){
    for(let i = 1; i<=1000000; i++){
        for(let j = 1; j<=1000000; j++){
            
        }
    }
}