const axios = require('axios');
const cherrio = require('cheerio');
const p = axios.get('https://www.cricbuzz.com/cricket-series/5945/indian-premier-league-2023/matches');
const arrOfMatches = [];
p.then(res=>{
    //console.log('HTML is ', res.data);
    const html = res.data;
    const $ = cherrio.load(html);
   const l =  $("h1").html();
   const divs = $(".cb-srs-mtchs-tm>a>span");
   divs.each((index, singleDiv)=>{
    arrOfMatches.push($(singleDiv).html());
    ;
   });
   console.log('All Matches Details ::::');
   arrOfMatches.forEach(match=>{
    console.log(match);
   })
   //console.log(divs.length);
   //console.log(l);

}).catch(e=>console.log('Error is ', e));