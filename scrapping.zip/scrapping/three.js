const pup = require('puppeteer');
async function load(){
const browser = await pup.launch({headless:false}); // open a browser
const page = await browser.newPage() ; // new tab
await page.goto("https://www.amazon.in/");

await page.type('#twotabsearchtextbox', 'Apple IPhone');
await page.click('#nav-search-submit-button');

}
load();