const axios = require('axios');
const p = axios.get('https://api.cricapi.com/v1/players?apikey=64f6e2ce-a6ca-4ec9-aed3-f5920a5788cf&offset=0');
p.then(res=>{
    console.log('Data is ', res.data.data);
    const arr = res.data.data;
    arr.forEach(e=>{
        console.log('Player Data is ', e.name);
    })
}).catch(e=>console.log('Error is ', e));