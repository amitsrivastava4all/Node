const fs = require('fs');
const path = require('path');
module.exports = function(data){
    const fullPath= path.join(__dirname,'logs/app.log');
    fs.appendFile(fullPath,data,(err)=>{
        if(err){
            console.log('Log Error ', err);
        }
    })
}
