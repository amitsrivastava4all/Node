const fs = require('fs');
const filePath = '/Users/amitsrivastava/Desktop/files/test.mp4';
const stream = fs.createReadStream(filePath, {highWaterMark:1024*100});
stream.on('open',(err)=>{
    console.log('Stream Open...');
})
stream.on('data', (chunk)=>{
    console.log('Chunk is ', chunk);
});
stream.on('end', ()=>{
    console.log('Data Ends .....');
});
stream.on('close', ()=>{
    console.log('Stream Close....')
});
stream.on('error', (err)=>{
    console.log('Error in Stream ', err);
})
/*fs.readFile(filePath, (err, content)=>{
    if(err){
        console.log('File Error ', err);
    }
    else{
        console.log('File ', content);
    }
});*/
console.log('Code Ends');