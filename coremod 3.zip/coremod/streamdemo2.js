const fs = require('fs');
const rStream = fs.createReadStream('/Users/amitsrivastava/Desktop/files/test.mp4');
const wStream = fs.createWriteStream('/Users/amitsrivastava/Desktop/files/copy.mp4');
// rStream.on('open',()=>{
//     console.log('Ready to Copy...');
// })
// rStream.on('data', chunk=>{
//     wStream.write(chunk);
// });
// rStream.on('end', ()=>{
//     console.log('Copy Done....');
// })
// rStream.on('error', err=>{
//     console.log('Error in Copy ', err);
// })
wStream.on('finish', ()=>{
    console.log('Copy Done....');
})
wStream.on('error', err=>{
    console.log('Error in Copy ', err);
})
 rStream.pipe(wStream); // Async



console.log('Done...');