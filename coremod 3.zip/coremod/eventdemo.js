const events = require('events');
const eventObject = new events.EventEmitter();

eventObject.setMaxListeners(100);
const e = eventObject.getMaxListeners();
console.log('Max ', e);
eventObject.once('ring', ()=>{
    console.log('Ring...');
})
eventObject.on('order-book',(data)=>{
    console.log('Order Booking Done.... ', data);

});
eventObject.on('order-book',(data)=>{
    console.log('Order Booking Done.... ',data);

});
eventObject.emit('ring');
eventObject.emit('ring');
//eventObject.off('order-book');


eventObject.emit('order-book','Amit'); // Event Fire
eventObject.emit('order-book',"ram");
eventObject.emit('order-book',"shyam");