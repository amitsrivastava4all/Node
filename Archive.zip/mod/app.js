module.exports = function(){
    console.log("I am the app js");
}
