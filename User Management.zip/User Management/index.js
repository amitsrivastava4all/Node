const express = require("express");
const dotenv = require("dotenv").config();
const bodyParser = require("body-parser"); // Old Way (For Getting the data from POST)
const mongodb = require("./database/mongoDB");
const app = express();
app.use(express.json()); // New Way
app.use(express.urlencoded({extended: true})); 
app.set("view engine", "ejs");

const loginController = require("./controllers/loginController");
const registerController = require("./controllers/registerController");
const logoutController = require("./controllers/logoutController");
const verifyController = require("./controllers/verifyController");

app.use(express.static("public"));

app.post("/login", loginController);
app.post("/register", registerController);
app.post("/logout", logoutController);
app.post("/verify", verifyController);

const PORT = process.env.PORT;
app.listen(PORT, (err) => {
  if (!err) {
    console.log(`Server is running on port ${PORT}`);
  }
});
