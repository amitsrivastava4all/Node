const languageBundleReader = ()=>{
    const lang = process.env.MYLANG;
    console.log('Lang is ', lang);
    if(lang == 'hi'){
        return require('../../../../i18n/hi.json');
    }
    else {
        return require('../../../../i18n/en.json');
    }
}
module.exports = languageBundleReader;