const nodemailer = require('nodemailer');
function sendMail(){
// Step-1 Create a SMTP Transport
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'GmailUserId', 
    pass: 'GmailPassword'
  }
});
const attachments = [{filename:'hellofriend.txt', content:fs.readFileSync('abcd.txt')}]
// Step-2 From , to 
const mailOptions = {
  from: 'GmailEmailId',
  to: 'SenderMailId,SenderMailId',
  subject: 'Subject',
  text: 'Email content',
  attachments:attachments
};

transporter.sendMail(mailOptions, function(error, info){
  if (error) {
 console.log(error);
  } else {
    console.log('Email sent: ' + info.response);
    // do something useful
  }
});
}
module.exports = sendMail;