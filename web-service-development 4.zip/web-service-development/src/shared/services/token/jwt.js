const jwt = require('jsonwebtoken');

const SECRET = 'UCANTSEEME';
const generateToken = (email)=>{
    const token = jwt.sign({email:email},SECRET,{
        
        expiresIn:'1d',

    });
    return token;
}

const compareToken = (tokenId)=>{
    let decode = jwt.verify(tokenId, SECRET);
    if(decode && decode.email){
            return true;
    }
    return false;
}
module.exports = {generateToken, compareToken};