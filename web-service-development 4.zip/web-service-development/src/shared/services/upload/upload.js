// // const fileUpload = require('express-fileupload');
// // app.use(fileUpload());

// if(!request.files || Object.keys(request.files).length==0){
//         response.status(500).json({message : 'NO files to Upload...'});
//     }
//     else{
//         file = request.files.file; // <input type='file' name='uploadfile'> field name
//         logger.debug(JSON.stringify(request.files.file.name));
//         logger.debug(UPLOAD_LOCATION);
//         let fullPath = path.join('/Users/amitsrivastava/Documents/web-service-development/upload-files','/', file.name);
//         file.mv(fullPath,err=>{
//             if(err){
//                 response.status(500).send(err);
//             }
//             else{
// 			response.status(200).send('Upload done');
// }
//         }
