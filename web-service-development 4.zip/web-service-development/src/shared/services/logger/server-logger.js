const fs = require('fs');


const serverLogStream = fs.
createWriteStream(process.env.SERVER_LOG, {
    interval: '7d' // rotate weekly

  });
  module.exports = serverLogStream;
