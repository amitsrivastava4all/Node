const {RESOURCE_NOT_FOUND} = require('../utils/constants/app-constants').STATUS_CODES;
const lang = require('../services/language/languge-bundle-reader')();
const error404 = (request, response, next)=>{
    response.status(RESOURCE_NOT_FOUND).json({message:lang['resource.not.found']});
}
module.exports = error404;