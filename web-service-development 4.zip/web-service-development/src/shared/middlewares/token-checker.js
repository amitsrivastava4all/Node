const { compareToken } = require("../services/token/jwt");
const {RESOURCE_NOT_FOUND} = require("../utils/constants/app-constants").STATUS_CODES;
module.exports = (request, response, next)=>{
    const token = request.headers['token'] ;
    try{
    const result = compareToken(token);
    if(result){
     next();
    }
    else{
      response.status(RESOURCE_NOT_FOUND).json({message:'UnAuthorize User'});
    }
  }
  catch(err){
    response.status(RESOURCE_NOT_FOUND).json({message:'UnAuthorize User'});
  }
}