// Client Id , Secret , CallBack URL
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth').OAuth2Strategy;

const clientId = "460875630053-cm9g46u3peqqg9fgkbpbq8jaqpbalo0i.apps.googleusercontent.com";
const clientSecret= "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";
passport.use(new GoogleStrategy({
    clientID: clientId,
    clientSecret: clientSecret,
    callbackURL: "http://localhost:1234/api/auth/google/callback"
  },
  function(accessToken, refreshToken, profile, done) {
      userProfile=profile;
      console.log('User Profile Data is ', userProfile);
      
      return done(null, userProfile);
  }
));

module.exports = passport;