const config = {
    SCHEMA :{
        USERS: 'users',
        ROLES:'roles'
    },
    ROUTES :{
        API_VERSION :'/api',
        USER_ROUTES:{
            LOGIN :'/login',
            REGISTER :'/register',
            PROFILE :'/profile'
        }
    },

    STATUS_CODES:{
        SUCCESS:200,
        RESOURCE_NOT_FOUND: 404,
        SERVER_ERROR : 500
    }

}
module.exports = config;