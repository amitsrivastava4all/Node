const { addNewRole } = require("../../domain/services/role-service");

const roleAdd = async (request, response)=>{
    const roleObject = request.body;
    try{
    const result = await addNewRole(roleObject);
    if(result && result._id){
        response.json({message:"Role Added..."});
    }
    else{
        response.json({message:"Error in Role Added..."});       
    }
}
catch(err){
    console.log("Error in Role ", err);
    response.json({message:"Error in Role Added..."}); 
}
}
module.exports = {roleAdd};