const express = require('express');
const { roleAdd } = require('../controllers/role-controller');
const router = express.Router();
router.post('/role-add', roleAdd);
module.exports = router;
