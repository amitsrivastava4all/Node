const express = require('express');
const { welcome } = require('../controllers/user-controller');
const router = express.Router();
router.get('/welcome', welcome);
module.exports = router;