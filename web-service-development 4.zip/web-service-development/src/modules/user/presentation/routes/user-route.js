const express = require('express');
const router = express.Router();
const path = require('path');
const passport = require('../../../../shared/utils/passport-config');
const {REGISTER, LOGIN, PROFILE} = require('../../../../shared/utils/constants/app-constants').ROUTES.USER_ROUTES;
const {register, login , profile, welcome } = require('../controllers/user-controller');
router.get(PROFILE, profile);
router.post(REGISTER, register);
router.post(LOGIN, login);
// calling google oauth
router.get('/auth/google', 
passport.authenticate('google', { scope : ['profile', 'email'],session:false }));
// this will call once u come back from google
router.get('/auth/google/callback',passport.authenticate('google', { failureRedirect: '/error' ,session:false}),
function(req, res) {
  console.log('Callback Req ', req.user);
  // Successful authentication, redirect success.
  res.redirect('/api/success?name='+req.user.displayName);
});

router.get('/success', (req, res)=>{
    const userName = req.query.name;
    res.json({message:'Welcome '+userName});
})
router.post('/uploadpic',(request, response)=>{
  // const fileUpload = require('express-fileupload');
// app.use(fileUpload());

if(!request.files || Object.keys(request.files).length==0){
  response.status(500).json({message : 'NO files to Upload...'});
}
else{
  file = request.files.file; // <input type='file' name='uploadfile'> field name
  console.log(JSON.stringify(request.files.file.name));
  
  let fullPath = path.join('/Users/amitsrivastava/Documents/web-service-development/upload-files','/', file.name);
  file.mv(fullPath,err=>{
      if(err){
          response.status(500).send(err);
      }
      else{
response.status(200).send('Upload done');
}
  });

}
});
module.exports = router;