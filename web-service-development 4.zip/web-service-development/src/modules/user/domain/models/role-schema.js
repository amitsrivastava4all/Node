
const mongoose = require('../../../../shared/services/db/connection');
const { Schema, SchemaTypes } = mongoose;
const {ROLES} = require('../../../../shared/utils/constants/app-constants').SCHEMA;
const roleSchema = new Schema({
    name:{type:SchemaTypes.String, required: true, unique:true},
    desc :{type:SchemaTypes.String},
    status :{type:SchemaTypes.String, default:'A'},
    rights:[{name:{type:SchemaTypes.String},status:{type:SchemaTypes.String}}] // Nested Document
});
const RoleModel = mongoose.model(ROLES, roleSchema);
module.exports = RoleModel;