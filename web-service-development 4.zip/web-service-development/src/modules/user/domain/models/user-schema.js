const { SchemaTypes } = require('mongoose');
const {USERS} = require('../../../../shared/utils/constants/app-constants').SCHEMA;
const mongoose = require('../../../../shared/services/db/connection');
const Schema = mongoose.Schema;

const schemaOptions = {
    autoCreate: false, // create the collection once u do save, false is default
    autoIndex : false ,  // create the index once u do save, false is default
   // _id: false, // off the _id generation
  //  id: true, // create the virtual property of _id so u can use id when u r getting _id
    // id only works when u do _id:true
    collection:'brainmentors_users', // give own collection name insted of using model name,
    capped:{size:1024, max:100} // max : 100 (records) and memory size (1024 bytes)
}
/*
About Capped Collection 
Capped collections are fixed-size collections that support high-throughput 
operations that insert and retrieve documents based on insertion order. 
Capped collections work in a way similar to circular buffers: once a
 collection fills its allocated space, it makes room for new documents 
 by overwriting the oldest documents in the collection.
*/


const userSchema = new Schema({
    'email':{type:SchemaTypes.String, required:true, 
        lowercase:true, unique:true},
        role:{type:SchemaTypes.ObjectId, ref:'roles' }, // Join
     'password':{type:SchemaTypes.String , 
        minLength:3, maxLength:100, trim:true, required:true},
        'name':{type:SchemaTypes.String, required:true},

        'phone':{type:Schema.Types.String,  validate:{
            validator:function(phoneValue){
                let max = 10;
                if(phoneValue.length!=max){
                    return false;
                }
                return true;
            },
            message:function(prop){
                let fieldName = prop.path;
                return 'Invalid Phone Number '+fieldName+'  '+prop.value;
            }
        }}

}, schemaOptions);
const UserModel = mongoose.model(USERS,userSchema);
module.exports = UserModel;