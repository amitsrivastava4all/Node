const RoleModel = require('../models/role-schema');
const addNewRole=async (roleObject)=>{
   
    return await RoleModel.create(roleObject); // Implict throw Exception
}
module.exports = {addNewRole};