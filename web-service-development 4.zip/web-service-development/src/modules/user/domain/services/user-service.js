// CRUD 
const UserModel = require('../models/user-schema');
const {hashPassword, comparePwd} = require('../../../../shared/services/encryption/password-hashing');
const userService = {
    async addNewUser(userObject){
        userObject.password = hashPassword(userObject.password);
        return await UserModel.create(userObject); // Implict throw Exception
    },
    async loginUser(userObject){
        try{
            const doc = await UserModel
            .findOne({'email':userObject.email}
            //{'email':1, 'password':1, 'name':1,'phone':1,'_id':0}
            ).populate({path:'role', select:'-_id name desc rights'}).exec();
            console.log('Doc is ', doc);
            if(doc && doc.email){
                if(comparePwd(userObject.password, doc.password)){
                    console.log('Password Check ', doc);
                    //return {'name':doc.name, 'email':doc.email};
                    return {doc:doc};
                }
                return null;
            }
            return null;
        }
        catch(err){
            console.log('Error in Login ', err);
            throw err;
           // throw new Error('hgdkfjhgkjf')
        }
    }
}
module.exports = userService;