const express = require('express');
const app = express();
const chalk = require('chalk');
const morgan= require('morgan');
const cors = require('cors');
const passport = require('passport');
const fileUpload = require('express-fileupload');
process.on('uncaughtException',(err)=>{
    // Error Log
    console.log('Error Happen ', err);
})

const {API_VERSION} = require('./src/shared/utils/constants/app-constants').ROUTES;
const appLogger = require('./src/shared/services/logger/app-logger')(__filename);
require('dotenv').config();
const serverLogStream = require('./src/shared/services/logger/server-logger');
// Load Env
// app.use(middleware); 
// middleware function
app.use(cors());
app.use(morgan('combined',{stream:serverLogStream}));
app.use(express.static('public'));
app.use(express.urlencoded());
app.use(express.json());
app.use(passport.initialize());
//app.use(passport.session()); // it use express session by default
// google auth after successful - it gives user object
passport.serializeUser(function(user, callBackFn) {
    callBackFn(null, user); // null is error (send to express session store)
  });
  // From Cookie get the session id and then based on get the user object
  passport.deserializeUser(function(obj, cb) {
    cb(null, obj);
  });
  app.use(fileUpload());
app.use(API_VERSION, require('./src/modules/user/presentation/routes/user-route'));
app.use(API_VERSION, require('./src/modules/user/presentation/routes/role-route'));


app.use(require('./src/shared/middlewares/token-checker'));
app.use(API_VERSION, require('./src/modules/user/presentation/routes/dashboard-route'));
app.use(require('./src/shared/middlewares/404'));
// app.get('/' , (req, res)=>{
//     res.setHeader('Access-Control-Allow-Origin', '10.10.20.1')
// })
const server = app.listen(process.env.PORT , (err)=>{
    if(err){
        console.log(chalk.red.bold('Server Crash '), err);
        appLogger.error('Server Crash')
    }
    else{
        console.log(chalk.greenBright.
            bold('Server Up and Running '+server.address().port));
            appLogger.debug('Server Up and Running');
    }
})