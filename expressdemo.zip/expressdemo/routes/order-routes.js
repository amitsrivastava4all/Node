const express = require('express');
const {orderBook,orderCancel,orderUpdate,getOrder} = require('../controllers/order-controller');
const {ORDER_BOOK,ORDER_CANCEL, ORDER_UPDATE,ORDER_VIEW} = require('../utils/config').ROUTES.ORDER_ROUTES;
const orderRouter = express.Router();
orderRouter.get(ORDER_VIEW, getOrder);
orderRouter.post(ORDER_BOOK, orderBook);
orderRouter.delete(ORDER_CANCEL, orderCancel);
orderRouter.put(ORDER_UPDATE, orderUpdate);
module.exports = orderRouter;