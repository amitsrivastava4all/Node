const express = require('express');
const {profile, login, register, changePassword} = require('../controllers/user-controller');
const {LOGIN, REGISTER,PROFILE, CHANGE_PASSWORD} = require('../utils/config').ROUTES.USER_ROUTES;
const userRouter = express.Router();
userRouter.get(PROFILE, profile);
userRouter.post(LOGIN, login);
userRouter.post(REGISTER, register);
userRouter.put(CHANGE_PASSWORD, changePassword);
module.exports = userRouter;