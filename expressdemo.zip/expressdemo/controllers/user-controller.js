const {ORDER_VIEW} = require('../utils/config').ROUTES.ORDER_ROUTES;
const path = require("path");
const userController = {
    login(request, response){
       // response.send('<h1>Login....</h1>');
       const userInfo = {userid:"ram", name:'Ram Kumar'};
       //response.json(userInfo);
      
        response.render('dashboard',{name:userInfo.name});
       //const fullPath =  path.join(path.normalize(__dirname+"/.."),"public", "login.html");
       //response.sendFile(fullPath);
       //response.redirect(ORDER_VIEW);
    },
    register(request, response){
        response.send('Register....');
    },
    changePassword(request, response){
        response.send('Change Password....');
    },
    profile(request, response){
        response.send('Profile....');
    }
}

module.exports = userController;