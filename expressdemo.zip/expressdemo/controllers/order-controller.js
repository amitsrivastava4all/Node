const orderController = {
    orderBook(request, response){
        response.send('Order Book....');
    },
    orderCancel(request, response){
        response.send('Order Cancel....');
    },
    orderUpdate(request, response){
        response.send('Order Update....');
    },
    getOrder(request, response){
        response.send('Order View....');
    }
}

module.exports = orderController;