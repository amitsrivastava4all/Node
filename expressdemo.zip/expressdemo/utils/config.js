module.exports = {
    ROUTES:{
        USER_ROUTES : {
            LOGIN : '/login',
            REGISTER : '/register',
            PROFILE : '/profile',
            CHANGE_PASSWORD: '/change-password'
        },
        ORDER_ROUTES :{
            ORDER_BOOK : '/book-order',
            ORDER_CANCEL : '/cancel-order',
            ORDER_UPDATE : '/change-order',
            ORDER_VIEW : '/view-order'
        }
    }
}