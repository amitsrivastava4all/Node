const express = require('express');
const app = express();

app.use(express.static('public')); // app.use(middleware)
app.set('view engine', 'ejs');
app.use('/', require('./routes/user-routes'));
app.use('/', require('./routes/order-routes'));
const server= app.listen(process.env.PORT || 1234,(err)=>{
    if(err){
        console.log('Server Crash ', server.address().port);
    }
    else{
        console.log('Server Start ', server.address().port );
    }
})
//console.log(typeof app);
//console.log(typeof express);