const chalk = require('chalk');
const http = require('http');
const figlet = require('figlet');
const path = require('path');
const fs = require('fs');
function servePage(response, fileName = 'index.html'){
    
   
   // response.setHeader('refresh', "3");
    const fullPath= path.join(__dirname,'public',fileName);
    const extension = path.extname(fullPath);
    console.log('Extension is ', extension);
    if(extension==='.css'){
        response.setHeader('Content-Type', 'text/css');
    }
    else if(extension ==='.mp4'){
        response.setHeader('Content-Type','video/mp4')
    }
    else{
        response.setHeader('Content-Type', 'text/html');
    }
    const readStream  = fs.createReadStream(fullPath);
    readStream.pipe(response);

}

function handleRequestAndResponse(request, response){
    console.log("Here Request Comes.... ", request.url);
    const urlString = request.url;
    if(urlString === '/'){
        servePage(response);
    }
    else {
        servePage(response, urlString);
    }
    //servePage(response);
    //console.log('Request Rec ');
    // response.setHeader('Content-Type', 'text/html');
    // response.setHeader('refresh', "3");
    //<meta http-equiv="refresh" content="10">
    // response.write('<h1>Hello Client......</h1>');
    //response.end();
}

const server = http.createServer(handleRequestAndResponse);
server.listen(process.env.PORT || 9755 , err=>{
    if(err){
        console.log(chalk.red.bold('Error During Server Up '), err);
    }
    else{
        figlet('Server UP.. ',(err, data)=>{
            if(err){
                console.log('Error in Figlet');
            }
            else{
                console.log(chalk.green.bold(data));
                console.log(chalk.yellow.bold('@ '+server.address().port));
            }
        })
        //console.log(chalk.green.bold('Server Up and Running '), server.address().port);
    }
})