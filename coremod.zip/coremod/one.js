// console.log(process);
const log = require('./log');
console.log('Argv ',process.argv);
console.log(process.cwd());
console.log(process.arch);
console.log('Port No ', process.argv[2]);
process.on('uncaughtException', (err)=>{
    const {message, stack,name } = err;
    //console.log( JSON.stringify({message, stack, name}));
    //console.log(JSON.stringify(err));
     log('Some Error '+JSON.stringify({message, stack, name}));   
    //console.log('Some Error ', err);
})
console.log(process.env.PWD);
console.log('Env is ', process.env.PORT || 1111);

//a++;
console.log('Hello Node JS...')
process.on('exit',()=>{
    console.log('Bye Bye...');
})
console.log('Hi Node JS ');


