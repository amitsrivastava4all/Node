const t = require('./exportvsmoduleexport');
console.log('T is ',t);
console.log('T add ', t.add);
//console.log(t.add());