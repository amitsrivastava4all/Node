import {add} from './two.js';
const t = add();
console.log('Value is ',t);